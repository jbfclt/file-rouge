export interface UserModel{
    userid: string,
    name: string,
     password: string,
     email: string,
     role: string,
    isActive: boolean

}